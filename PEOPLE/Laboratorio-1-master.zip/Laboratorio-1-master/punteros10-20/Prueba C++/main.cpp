#include <iostream>
using namespace std;

void func();        //es importante declarar el metodo, por que si no, no reconoce el metodo en la funcion principal
int main()
{
    /*
    int edad=10;
    int num1=20;
    int num2=30;
    int respuesta;

    //en c++ la clave "BARRA N" es igual a la de C

    int numero=5;
    cout <<"Hola mundo";
    cout <<"\nSize de char: " <<sizeof(char);

    cout <<"\nEl numero es: "  <<numero <<" y la edad es " <<edad;

    //cout "imprimira" lo que esta en "" seguido de lo que haya en la variable "numero" despues imprimira lo que se
    //encuentre en la variable edad
    cout <<"\n\n";

    //-------------calculadora--------------

    cout <<num1 <<" + " <<num2;
    respuesta = num1 +num2;

    cout <<"\nEl Resultado es : "<<respuesta;
    */

    //--------------Metodos-----------------
    func();
}
void func(){
cout <<"Prueba Metodos";
}




